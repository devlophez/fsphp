<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("Definindo Ambiente");

/*
 * 
 */
fullStackPHPClassSession("Debug Section", __LINE__);

var_dump($_SERVER);