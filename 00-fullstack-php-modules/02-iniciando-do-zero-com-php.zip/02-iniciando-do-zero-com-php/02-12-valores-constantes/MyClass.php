<?php

namespace Source;

class MyClass
{
    public $nameSpace = __NAMESPACE__;
}