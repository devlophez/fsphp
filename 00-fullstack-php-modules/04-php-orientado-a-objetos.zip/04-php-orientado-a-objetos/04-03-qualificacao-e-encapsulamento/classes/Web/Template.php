<?php

namespace Web;

class Template
{
    public $web;
}